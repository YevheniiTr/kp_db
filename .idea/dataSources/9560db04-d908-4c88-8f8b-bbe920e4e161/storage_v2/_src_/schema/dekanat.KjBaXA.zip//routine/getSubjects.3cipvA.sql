create procedure getSubjects(IN ID INT(10))
BEGIN
	SELECT  subjName 
    FROM lecturer l join subjectt  s join payment p 
    on l.ID=p.lectID and s.ID = p.SubjectID 
    WHERE l.ID = ID;
END;

