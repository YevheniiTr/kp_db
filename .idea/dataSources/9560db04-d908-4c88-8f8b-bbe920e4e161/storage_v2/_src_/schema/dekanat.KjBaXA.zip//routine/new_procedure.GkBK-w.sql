create procedure new_procedure(IN cg VARCHAR(2), IN n INT(10))
BEGIN
declare 
	count int;
SET count = (SELECT count(student.studentID) FROM stgroup join student join stsession join subjectt
ON stgroup.groupID = student.groupID and stsession.studentID=student.studentID and subjectt.ID = stsession.subjectID
WHERE  mark < 60 and codeGroup = cg and  num = n);

IF (count <=0 )   THEN SELECT 'В указанной группе нет должников',count,cg AS codeGroup,n as num;
else  SELECT count,cg AS codeGroup,n as num;
END IF;
END;

