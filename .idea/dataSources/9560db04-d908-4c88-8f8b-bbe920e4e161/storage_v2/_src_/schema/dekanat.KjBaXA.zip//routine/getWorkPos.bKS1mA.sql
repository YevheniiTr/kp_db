create procedure getWorkPos()
BEGIN
SELECT    workPos,salary,hours,startSalary, (salary*hours + startSalary)*12 AS ZP from lecturer join payment join posada
on lecturer.ID = payment.lectID and lecturer.posadaID = posada.PositionID
where workPos IN('Доцент','Декан','ЗавідувачКафедри','СтаршийВикладач','Викладач','асистент','Професор')
group by posada.workPos;

END;

